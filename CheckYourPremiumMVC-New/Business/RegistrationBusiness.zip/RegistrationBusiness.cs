﻿using Domain;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace Business
{
    public interface IRegistrationBusiness
    {
        List<customSelectList> GetGender();
        List<customSelectList> GetCountry();
        //long saveRegistration(RegistrationDetails Details);
        //long saveLogin(RegistrationDetails Details);
        long saveRegistration(RegistrationDetails Details);
        long saveLogin(RegistrationDetails Details);
        string attamttime(LoginDetails Details);
        string savePassword(LoginDetails details);
        List<RegistrationDetails> GetLoginData(RegistrationDetails objuserlogin);
    }
    public class RegistrationBusiness : IRegistrationBusiness
    {
        private readonly CheckyrpremiumEntities db;
        public RegistrationBusiness()
        {

            db = new CheckyrpremiumEntities();

        }

        public List<customSelectList> GetGender()
        {
            try
            {
                //  var destinationList = db.Travel_Insurance.Where(x => x.Plans == "ABC").Select(x => new { x.Premium, x.SumInsured,x.Travel_id }).OrderByDescending(x => x.Travel_id).ToList();
                var gender = db.tb_GodigitGender.AsQueryable().AsEnumerable().Select(x => new customSelectList { value = x.Gender.ToString(), text = x.Gender.ToString() }).Distinct().ToList();
                return gender;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return new List<customSelectList>();
        }
        public List<customSelectList> GetCountry()
        {
            try
            {

                var gender = db.tbl_travelCountry.AsQueryable().AsEnumerable().Select(x => new customSelectList { value = x.County.ToString(), text = x.County.ToString() }).Distinct().ToList();
                return gender;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return new List<customSelectList>();
        }
        public long saveRegistration(RegistrationDetails Details)
        {
            var tdetails = new Reg_tbl
            {
                FirstName = Details.FirstName,
                LastName = Details.LastName,
                EmailId = Details.EmailId,
                // Dob = DateTime.ParseExact(Details.DOB, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture),
                Dob = Convert.ToDateTime(Details.DOB),
                Gender = Details.Gender,
                MobileNo = Details.MobileNo,
                Address = Details.Address,
                Country = Details.Country,
                Password = Details.Password,
                ConfirmPassword = Details.ConfirmPassword,
                Picture = ""

            };
            db.Reg_tbl.Add(tdetails);
            db.SaveChanges();
            var tid = Details.Id;
            return tid;
        }
        public long saveLogin(RegistrationDetails Details)
        {
            var tDetails = new LoginReg_tbl
            {
                EmailId = Details.EmailId,
                MobileNo = Details.MobileNo,
                UserType = "Costumer",
                Password = Details.Password,
                UserName=Details.FirstName+" "+Details.LastName,
                AlltemtTime=0
            };
            db.LoginReg_tbl.Add(tDetails);
            db.SaveChanges();
            var Tid = Details.Id;
            return Tid;
        }
        //public List<RegistrationDetails> GetLoginData(RegistrationDetails objuserlogin)
        //{
        //    try {
         
        //       var loginuser = db.LoginReg_tbl.AsEnumerable().Where(x =>
        //            x.Password == objuserlogin.Password && x.EmailId == objuserlogin.EmailId 
        //           ).FirstOrDefault();
                 
        //        var registration=db.Reg_tbl.AsEnumerable().Where(x =>
        //             x.Password == objuserlogin.Password && x.EmailId == objuserlogin.EmailId 
        //             ).FirstOrDefault();
        //        objuserlogin.FirstName = registration.FirstName;
        //        objuserlogin.LastName = registration.LastName;
                
               
        //    }
        //    catch (Exception ex)
        //    { }
        //    return new List<RegistrationDetails>();
            
        //}
        //Poonam ......................................................
        public List<RegistrationDetails> GetLoginData(RegistrationDetails objuserlogin)
        {
            try
            {

               
                var registration = db.LoginReg_tbl.AsEnumerable().Where(x =>
                     x.Password == objuserlogin.Password && x.EmailId == objuserlogin.EmailId || x.MobileNo == objuserlogin.EmailId).Select(
                    x => new RegistrationDetails
                    {
                        EmailId = x.EmailId,
                        MobileNo = x.MobileNo,
                        Password = x.Password,
                       FirstName=x.UserName,
                        //MobileNo=x.MobileNo
                    }).ToList();

                return registration;
            }
            catch (Exception ex)
            { }


            return new List<RegistrationDetails>();

        }
        //14 march
        public string savePassword(LoginDetails details)
        {
            var result = db.LoginReg_tbl.SingleOrDefault((x => x.Password == details.Password&&x.EmailId==details.EmailId));
            if (result != null)
            {
                result.Password = details.NewPassword;
                db.SaveChanges();
                return result.ToString();
            }
            var tid = details.UserId;
            return "";
        }
        //14 march
        //ppppp End.........................
        public string attamttime(LoginDetails Details)
        {
            try
            {

                var result = db.LoginReg_tbl.SingleOrDefault(x =>x.EmailId == Details.EmailId);
                int timeatt = Convert.ToInt32(result.AlltemtTime) + 1;
                result.AlltemtTime = timeatt;
                if (result != null)
                {
                    if (timeatt > 5)
                    {
                        return result.ToString();
                    }
                    else
                    {
                        result.AlltemtTime = timeatt;
                        db.SaveChanges();
                        return result.ToString();
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
             return "";
        }

    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Business;
using Domain;
using CheckYourPremiumMVC.Models;

namespace CheckYourPremiumMVC.Controllers
{
    public class HealthPlanController : Controller
    {
        //
        // GET: /HealthPlan/
        public IHealthBusiness _IHealthBusiness;
        public ITravelBusiness _ITravelBusiness;
        public ICommonBusiness _IProposerBusiness;
        public ICommonBusiness _ITravellerBusiness;

        public List<string> triptype;
        public List<string> relations;
        public List<string> isPassport;
        string secretKey = string.Empty;
        string apiKey = string.Empty;
        public HealthPlanController()
        {
            _IHealthBusiness = new HealthBusiness();
            _ITravelBusiness = new TravelBusiness();
            _IProposerBusiness = new ProposerBusiness();
            _ITravellerBusiness = new TravellerBusiness();
            triptype = new List<string>();
            relations = new List<string>();
            isPassport = new List<string>();
            triptype.Add("Single");
            triptype.Add("Multi");

            isPassport.Add("Yes");
            isPassport.Add("No");
            secretKey = System.Configuration.ConfigurationSettings.AppSettings["SBIClientId"].ToString();
            apiKey = System.Configuration.ConfigurationSettings.AppSettings["SBISecretKey"].ToString();
        }
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetQuoteDetail()
        {

            if (Session["EmailID"] == null)
            {
                return RedirectToAction("ComingSoon", "Home");
            }
            BindDropdown();
            return View();
        }

        public void BindDropdown()
        {
            var destinations = _IHealthBusiness.GetAllCity();
            SelectList destinationsSelectList = new SelectList(destinations, "text", "value");
            ViewData["Cities"] = destinationsSelectList;
            //SelectList listTripType = new SelectList(triptype);
            //ViewData["listTripType"] = listTripType;
        }
        public void BindCoverage()
        {
            var Coverages = _IHealthBusiness.GetAllCoverAge();
            SelectList CoveragesSelectList = new SelectList(Coverages, "text", "value");
            ViewData["Coverage"] = CoveragesSelectList;
            //SelectList listTripType = new SelectList(triptype);
            //ViewData["listTripType"] = listTripType;
        }
        public void BindCheckForYear()
        {
            var CoveragesYear = _IHealthBusiness.GetAllYear();
            SelectList CoveragesYearSelectList = new SelectList(CoveragesYear, "text", "value");
            ViewData["CoverageYear"] = CoveragesYearSelectList;
            //SelectList listTripType = new SelectList(triptype);
            //ViewData["listTripType"] = listTripType;
        }
        //Poonam......................
        public void BindBajajRelation()
        {
            var relation = _IHealthBusiness.GetBajajRelation();
            SelectList selectList = new SelectList(relation, "text", "value");
            ViewData["relation"] = selectList;
        }
        public void BindBajajOccupation()
        {
            var occupation = _IHealthBusiness.GetBajajOccupation();
            SelectList selectList = new SelectList(occupation, "text", "value");
            ViewData["occupation"] = selectList;
        }
        //poonam .......End.....code
        [HttpPost]
        public ActionResult GetQuoteDetail(HealthPlanDetails Health)
        {
            string SumInsurred = "100000.00";
            if (!ModelState.IsValid)
            {
                BindDropdown();
                return View(Health);
            }
            var Tid = _IHealthBusiness.SaveHealthSearch(Health);
            int Child = Convert.ToInt32(Health.son);
            int Adult = Convert.ToInt32(Health.chkspouses);
            int Self = Convert.ToInt32(Health.chkself);
            int ageSelf = Convert.ToInt32(Health.ageSelf);
           
            return RedirectToAction("QResult/" + Tid, "HealthPlan", new { @AgeAdult = ageSelf, @Self = Self, @Adult = Adult, @Child = Child });

        }
        public ActionResult QResult(string ID, string AgeAdult, string Self, string Adult, string Child)
        {
            BindCoverage();
            BindCheckForYear();
            ViewData["son"] = Child;
            ViewData["ageSelf"] = AgeAdult;
            ViewData["Self"] = Self;
            ViewData["Spouses"] = Adult;
            ViewData["HID"] = ID;
             //Login Session Code..........
            //Session["HID3"] = ViewData["HID"].ToString();
            //Session["Spouses3"] = ViewData["Spouses"].ToString();
            //Session["Self3"] = ViewData["Self"].ToString();
            //Session["ageSelf3"] = ViewData["ageSelf"].ToString();
            //Session["son3"] = ViewData["son"].ToString();
            return View();
        }
        [HttpPost]
        public JsonResult BindPremiumList(int draw, int start, int length, string searchTxt, string AgeAdult, string Self, string Adult, string Child, string SumInsured, string CoverForYear,string ID)
        {
            JsonTableData jsonData = new JsonTableData();

            try
            {
                string searchKey = Request["search[value]"];
                string order = Request["order[0][column]"];
                string orderby = Request["order[0][dir]"];
                searchTxt = searchKey.Trim().ToLower();
                HealthPlanDetails objSearchHealthInsurance = new HealthPlanDetails();
                View_HealthinsuranceModel objSearchHealthInsurance1 = new View_HealthinsuranceModel();
                objSearchHealthInsurance.ageSelf = AgeAdult;
                objSearchHealthInsurance.Self = Self;
                objSearchHealthInsurance.son = Child;
                objSearchHealthInsurance.Spouses = Adult;

                objSearchHealthInsurance.SumInsured= SumInsured;
                objSearchHealthInsurance1.SumAssured = SumInsured;
                objSearchHealthInsurance1.ageSelf = AgeAdult;
                objSearchHealthInsurance1.Self = Self;
                objSearchHealthInsurance1.son = Child;
                objSearchHealthInsurance1.Spouses = Adult;
                objSearchHealthInsurance1.CoverForYear = CoverForYear;
               
                objSearchHealthInsurance1.PlanID =ID;
                objSearchHealthInsurance.CoverForYear = CoverForYear;
                //objSearchHealthInsurance.ag = stayDays;
                //objSearchHealthInsurance.destination = destination;
                
                List<View_HealthinsuranceModel> list = _IHealthBusiness.GetHealthPremiumList(objSearchHealthInsurance);
                List<View_HealthinsuranceModel> lst = _IHealthBusiness.GetPremiumList(objSearchHealthInsurance1);
               
                var commonList = list;
                list.AddRange(lst);
                commonList = list;
                if (!string.IsNullOrEmpty(searchTxt))
                {
                    //commonList = commonList.Where(x => x.EDesigName.ToLower().Trim().Contains(searchTxt.ToLower().Trim())).ToList();
                }

                switch (order)
                {
                    //case "1":
                    //    commonList = orderby.Equals("asc") ? commonList.OrderBy(x => x.EDesigName).ToList() : commonList.OrderByDescending(x => x.EDesigName).ToList();
                    //    break;
                    default:
                        commonList = orderby.Equals("desc") ? commonList.OrderBy(x => x.SumAssured).ToList() : commonList.OrderByDescending(x => x.SumAssured).ToList();
                        break;
                }


                jsonData.recordsTotal = commonList.Count;
                jsonData.recordsFiltered = commonList.Count;
                jsonData.draw = draw;
                commonList = length != -1 ? commonList.Skip(start).Take(length).ToList() : commonList;
                List<List<string>> DetailList = new List<List<string>>();
                string action = string.Empty;


                var i = 1;
                foreach (var item in commonList)
                {

                    decimal P = Convert.ToDecimal(item.BeforeServiceTax??"0");
                    decimal Premium = P * Convert.ToDecimal((item.Gsttax)) / 100;
                    decimal Premium1 = P + Premium;
                    string pre = Premium1.ToString();
                    string column1 = "<img src=" + item.Logo + " />";
                    string column2 = "<p>" + item.PremiumDesc.ToUpper() + "<p>";
                    string column3 = "<p>" + item.SumAssured + "<p>";

                    string column4Premium = "<span><i class='fa fa-inr' aria-hidden='true'></i></span> " + (item.ProductName == "Star Health Insurance" ? item.Premium.ToString() : pre) + "<br src='#'><a class='AddD' href='#' onclick='NavigateDetail(" + item.PremiumChartID + ")'>Buy This Plan</a>";
                    //string col4 = "<button  style='border:none;' onclick='navigateEdit(" + item.EDesigId + ")'  type='submit'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></button><button onclick='navigatedel(" + item.EDesigId + ")' style='border:none;' type='submit'><i class='fa fa-trash-o' aria-hidden='true'></i></button>";
                    List<string> common = new List<string>();
                    common.Add(column1);
                    common.Add(column2);
                    common.Add(column3);
                    common.Add(column4Premium);

                    DetailList.Add(common);


                }
                jsonData.data = DetailList;
                return new JsonResult()
                {
                    Data = jsonData,
                    MaxJsonLength = Int32.MaxValue,
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }
            catch (Exception ex)
            {
                (new ErrorLog()).Error(ex.ToString(), "");
                return Json(null);
            }
        }

        //public ActionResult GetQuoteDetails(string Id, string tid)
        //{
        //    if (string.IsNullOrEmpty(Id) || string.IsNullOrEmpty(tid))
        //    {
        //        return RedirectToAction("GetQuote");
        //    }
        //    SelectList lstRealtion = new SelectList(relations);
        //    ViewData["relations"] = lstRealtion;
        //    SelectList lstPassport = new SelectList(isPassport);
        //    ViewData["lstPassport"] = lstPassport;
        //    var quotationDetail = _IHealthBusiness.GetQuotationDetail(Id, tid);
        //    return View(quotationDetail);
        //    return View();
        //}
        public void BindDesease()
        {
            var desease = _ITravelBusiness.GetIllness();
            SelectList selectList = new SelectList(desease, "text", "value");
            ViewData["desease"] = selectList;
        }
        public void BindRelations(string planId)
        {

            var relations = _IHealthBusiness.GetRelations(planId);
            SelectList selectList = new SelectList(relations, "text", "value");
            ///  SelectList selectList = new SelectList(relations);
            if (planId != "0")
            {
                ViewData["relations"] = selectList;
            }
            else
            {
                ViewData["nomineeRelations"] = selectList;
            }

        }
        public void BindOccupation(string planId)
        {
            var occupationList = _IHealthBusiness.GetOccupation(planId);
            SelectList selectList = new SelectList(occupationList, "text", "value");
            ///  SelectList selectList = new SelectList(relations);
            ViewData["occupationList"] = selectList;

        }
        public void BindAssigneeRelation(string type, Int32 planId)
        {
            var CoverAgeAmount = _IHealthBusiness.GetAssigneeNominee(type, planId);
            SelectList CoverAgeAmountSelectList = new SelectList(CoverAgeAmount, "text", "value");
            ViewData["assigneerelations"] = CoverAgeAmountSelectList;

        }
        public ActionResult GetHealthQDetais(string Id, string tid)
        {

            //// Login Session Code.....
            //if (Session["UserName"] == null)
            //{
            //    Session["IdNum3"] = Id;

            //}

            //if (Session["UserName"] != null)
            //{

            //    HealthPlanDetails Health = new HealthPlanDetails();
            //    if (Id == null)
            //    {
            //        string Tid = Session["HID3"].ToString();
            //        tid = Tid;
            //        Id = Session["IdNum23"].ToString();
            //        Response.Cookies["page"].Value = "";
            //    }
            //}
            //else
            //{


            //    Response.Cookies["page"].Value = "GetHealthQDetais";
            //    Response.Cookies["page"].Expires = DateTime.Now.AddHours(1);
            //    return RedirectToAction("LoginDetails", "RegistrationLogin");
            //}
            ////End....................
            if (string.IsNullOrEmpty(Id) || string.IsNullOrEmpty(tid))
            {
                return RedirectToAction("GetQuote");
            }
            BindDesease();
            BindRelations(Id);
            BindOccupation(Id);
            BindRelations("0");
            BindAssigneeRelation("health",Convert.ToInt32(Id));
            //SelectList lstRealtion = new SelectList(relations);
            //ViewData["relations"] = lstRealtion;
            SelectList lstPassport = new SelectList(isPassport);
            ViewData["lstPassport"] = lstPassport;
            var quotationDetail = _IHealthBusiness.GetQuotationDetail(Id, tid);
            return View(quotationDetail);

        }

        [HttpPost]
        public ActionResult GetHealthQDetais(HealthProposalRequest healthQuatationDetail)
        {
            //if (!ModelState.IsValid)
            //{
            //    BindDesease();


            //    SelectList lstRealtion = new SelectList(relations);
            //    ViewData["relations"] = lstRealtion;
            //    SelectList lstPassport = new SelectList(isPassport);
            //    ViewData["lstPassport"] = lstPassport;
            //    return View(healthQuatationDetail);
            //}

            _IProposerBusiness.SaveInfo(healthQuatationDetail);
            _ITravellerBusiness.SaveInfo(healthQuatationDetail);
            
            string res = _IHealthBusiness.SubmitProposal(healthQuatationDetail);

            BindDesease();


            BindRelations(healthQuatationDetail.planId.ToString());
            BindOccupation(healthQuatationDetail.planId.ToString());
            BindRelations("0");
            BindAssigneeRelation("health", Convert.ToInt32(healthQuatationDetail.planId));
            SelectList lstPassport = new SelectList(isPassport);
            ViewData["lstPassport"] = lstPassport;
            if (!string.IsNullOrEmpty(res) && !res.Contains("error"))
            {
                ViewBag.SecretKey = secretKey;
                ViewBag.APIKey = apiKey;
                ViewBag.referenceId = res;
                ///return RedirectToAction("ProposalStatus", "HealthPlan", new { @refid = res });
            }
            else
            {
                ViewData["Error"] = res.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");

            }
            return View(healthQuatationDetail);
        }
        public ActionResult GetHealthBajajDetais(string Id, int tid)
        {
            BindBajajRelation();//ppppppppppppppppppppp
            BindBajajOccupation();//pppppppppppppppppp

            var quotationDetail = _IHealthBusiness.GetQuotationBsjajDetail(Id, tid);
            return View(quotationDetail);
        }
         [HttpPost]
        public ActionResult GetHealthBajajDetais(HealthProposalRequest healthQuatationDetail)
        {
            BindBajajRelation();//ppppppppppppppppppppp
            BindBajajOccupation();//pppppppppppppppppp
            _IProposerBusiness.SaveInfo(healthQuatationDetail);
            _ITravellerBusiness.SaveInfo(healthQuatationDetail);

            string res = _IHealthBusiness.SubmitProposal(healthQuatationDetail);

            BindDesease();


            BindRelations(healthQuatationDetail.planId.ToString());
            BindOccupation(healthQuatationDetail.planId.ToString());
            BindRelations("0");
            BindAssigneeRelation("health", Convert.ToInt32(healthQuatationDetail.planId));
            SelectList lstPassport = new SelectList(isPassport);
            ViewData["lstPassport"] = lstPassport;
            if (!string.IsNullOrEmpty(res) && !res.Contains("error"))
            {
                ViewBag.SecretKey = secretKey;
                ViewBag.APIKey = apiKey;
                ViewBag.referenceId = res;
                ///return RedirectToAction("ProposalStatus", "HealthPlan", new { @refid = res });
            }
            else
            {
                ViewData["Error"] = res.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");

            }
            BindBajajRelation();//ppppppppppppppppppppp
            BindBajajOccupation();//pppppppppppppppppp
            return View(healthQuatationDetail);
        }
        public ActionResult ProposalStatus(string refid)
        {
            ViewBag.SecretKey = secretKey;
            ViewBag.APIKey = apiKey;
            ViewBag.referenceId = refid;
            return View();
        }
        [HttpPost]
        public ActionResult GenerateToken(string refId)
        {
            var redirectToken = _IHealthBusiness.GenerateToken(refId);
            // var redirectToken = "60b393827113566ce99e5160373c5331";
            ViewBag.RedirectToken = redirectToken;
            return Json(new { token = redirectToken }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GenerateTokenBajaj(string refId)
        {
            //var redirectToken = _IHealthBusiness.GenerateToken(refId);
            // var redirectToken = "60b393827113566ce99e5160373c5331";
            ViewBag.RedirectToken = refId;
            return Json(new { token = refId }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetPaymentStatus(string purchaseToken)
        {
            if (!string.IsNullOrEmpty(purchaseToken))
            {
                var policyStatus = _ITravelBusiness.PolicyStatus(purchaseToken);
                if (policyStatus.Count == 4)
                {
                    ViewBag.ReferenceNumber = (policyStatus["RefNumber"] ?? "").ToString();
                    ViewBag.PolicyNumber = policyStatus["PolicyNumber"].ToString();
                    ViewBag.RefId = policyStatus["RefId"].ToString();
                    ViewBag.PolicyStatus = policyStatus["PolicyStatus"].ToString();
                }
                else
                {
                    ViewBag.RefId = policyStatus["RefId"].ToString();
                    ViewBag.PolicyStatus = policyStatus["PolicyStatus"].ToString();
                    ViewBag.Note = policyStatus["Note"].ToString().Replace("{", "").Replace("}", "").Replace(@"""", "");

                }


            }
            return View();
        }
        [HttpGet]
        public ActionResult Download(string refid)
        {

            var response = _ITravelBusiness.GetDocument(refid);
            return File(response, "application/pdf");

        }

        public ActionResult GetCity(string pinCode)
        {
            
            var response = _IHealthBusiness.GetCityList(pinCode);
           // var result = response != null && !response[0].Contains("error") ? new { data = response, status = "success" } : new { data = response, status = "error" };
            //return Json(result, JsonRequestBehavior.AllowGet);
            return Json(response, JsonRequestBehavior.AllowGet);

        }
        public ActionResult GetArea(string pinCode, string cityId)
        {

            var response = _IHealthBusiness.GetArea(pinCode, cityId);
            return Json(response, JsonRequestBehavior.AllowGet);

        }


        public ActionResult GetCityBajaj(string pinCode)
        {

            
            var relations = _IHealthBusiness.GetBlockCity(pinCode);
            if (relations.Count == 0)
            {
                var response = _IHealthBusiness.GetCityList(pinCode);
                // var result = response != null && !response[0].Contains("error") ? new { data = response, status = "success" } : new { data = response, status = "error" };
                //return Json(result, JsonRequestBehavior.AllowGet);
                return Json(response, JsonRequestBehavior.AllowGet);
            }
            return Json(0, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetAreaBajaj(string pinCode, string cityId)
        {

            var response = _IHealthBusiness.GetArea(pinCode, cityId);
            return Json(response, JsonRequestBehavior.AllowGet);

        }

        public ActionResult GetQuoteSBI()
        {

            return View();
        }
        public ActionResult GetBajajPaymentStatus()
        {
            return View();
        }
    }
}

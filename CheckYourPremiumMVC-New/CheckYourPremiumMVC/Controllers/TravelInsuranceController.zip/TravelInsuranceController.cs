﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Business;
using Domain;
using CheckYourPremiumMVC.Models;
using Newtonsoft.Json;
using System.Text;
using System.Net;
using System.IO;
namespace CheckYourPremiumMVC.Controllers
{
    public class TravelInsuranceController : Controller
    {
        // GET: TravelInsurance
        public ITravelBusiness _ITravelBusiness;
        public ICommonBusiness _IProposerBusiness;
        public ICommonBusiness _ITravellerBusiness;
        public IBhartiAxa _IBhartiAxaTravel;
        public List<string> triptype;
        public List<string> relations;
        public List<string> isPassport;
        string secretKey = string.Empty;
        string apiKey = string.Empty;
        public TravelInsuranceController()
        {
            _ITravelBusiness = new TravelBusiness();
            _IProposerBusiness = new ProposerBusiness();
            _ITravellerBusiness = new TravellerBusiness();
            _IBhartiAxaTravel = new BhartiAxa();
            triptype = new List<string>();
            relations = new List<string>();
            isPassport = new List<string>();
            triptype.Add("Single");
            triptype.Add("Multi");
            relations.Add("Sibling");
            relations.Add("Child");
            relations.Add("Niece");
            relations.Add("GrandParent");
            relations.Add("GrandChild");
            relations.Add("Brother-in-Law");
            relations.Add("Sister-in-Law");
            relations.Add("Nephew");
            relations.Add("Parent");
            relations.Add("Spouse");
            isPassport.Add("Yes");
            isPassport.Add("No");
            secretKey = System.Configuration.ConfigurationSettings.AppSettings["StarSecretKey"].ToString();
            apiKey = System.Configuration.ConfigurationSettings.AppSettings["StarAPIKey"].ToString();
        }

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetQuote()
        {

            if (Session["EmailID"] == null)
            {
                return RedirectToAction("ComingSoon", "Home");
            }
            BindDropdown();
            return View();
        }
        public void BindDropdown()
        {
            var destinations = _ITravelBusiness.GetAllDestination();
            SelectList destinationsSelectList = new SelectList(destinations, "text", "value");
            ViewData["Destinations"] = destinationsSelectList;
            SelectList listTripType = new SelectList(triptype);
            ViewData["listTripType"] = listTripType;
        }
        public void BindCoverageAmount()
        {
            var CoverAgeAmount = _ITravelBusiness.GetAllCoverAgeAmount();
            SelectList CoverAgeAmountSelectList = new SelectList(CoverAgeAmount, "text", "value");
            ViewData["CoverageAmount"] = CoverAgeAmountSelectList;

        }
        public void BindAssigneeRelation(string type, Int32 planId)
        {
            var CoverAgeAmount = _ITravelBusiness.GetAssigneeNominee(type, planId);
            SelectList CoverAgeAmountSelectList = new SelectList(CoverAgeAmount, "text", "value");
            ViewData["assigneerelations"] = CoverAgeAmountSelectList;

        }
        public void BindRelations()
        {
            //  var relations = _ITravelBusiness.GetRelations();
            //   SelectList selectList = new SelectList(relations, "text", "value");
            SelectList selectList = new SelectList(relations);
            ViewData["relations"] = selectList;

        }
       
        public void BindRelationStar()
        {
            var CoverAgeAmount = _ITravelBusiness.GetReltionStar();

            SelectList selectlist = new SelectList(CoverAgeAmount, "value", "text");
            ViewData["relationsstar"] = selectlist;
        }
        public void BindRelationGodit()
        {
            var CoverAgeAmount = _ITravelBusiness.GetReltionStar();

            SelectList selectlist = new SelectList(CoverAgeAmount, "value", "text");
            ViewData["relationsGodit"] = selectlist;
        }
        public void BindPurpose()
        {
            var purpose = _ITravelBusiness.GetPurpose();
            SelectList destinationsSelectList = new SelectList(purpose, "text", "value");
            ViewData["TravelPurpose"] = destinationsSelectList;
        }
        public void BindGender()
        {
            var purpose = _ITravelBusiness.GetGender();
            SelectList destinationsSelectList = new SelectList(purpose, "text", "value");
            ViewData["TravelGender"] = destinationsSelectList;
        }
        public void BindDesease()
        {
            var desease = _ITravelBusiness.GetIllness();
            SelectList selectList = new SelectList(desease, "text", "value");
            ViewData["desease"] = selectList;
        }
        //.............ponam
        /// <summary>
        public void BindIProfession()
       {
           var ilness = _ITravelBusiness.GetProfession();
            SelectList selectList = new SelectList(ilness, "text", "value");
            ViewData["illness"] = selectList;
        }
        public void BindState()
        {
            var state = _ITravelBusiness.GetGodigitState();
            SelectList selectList = new SelectList(state, "text", "value");
            ViewData["GoDigitstate"] = selectList;
        }
        public void BindCountry()
        {
            var country = _ITravelBusiness.GetGodigitCountry();
            SelectList selectList = new SelectList(country, "text", "value");
            ViewData["GoDigitCountry"] = selectList;
        }
        public void BindMarialStatus()
        {
            var marialstatus = _ITravelBusiness.GetGodigitMarialStatus();
            SelectList selectList = new SelectList(marialstatus, "text", "value");
            ViewData["GoDigitMaterial"] = selectList;
        }
        /// ////////////////////////////////
        /// </summary>
        public void BindVisaType()
        {
            var lstVisaType = _ITravelBusiness.GetVisaType();
            SelectList selectList = new SelectList(lstVisaType, "text", "value");
            ViewData["visaType"] = selectList;
        }
        public void BindPlaceOfVisit(string compid)
        {
            var lstPlaceOfVisit = _ITravelBusiness.GetPlaceOfVisit(compid);
            SelectList selectList = new SelectList(lstPlaceOfVisit, "text", "value");
            ViewData["PlaceOfVisit"] = selectList;
        }
        [HttpPost]
        public ActionResult GetQuote(SearchTravelInsurance searchTravelInsurance)
        {
            if (!ModelState.IsValid)
            {
                BindDropdown();
                return View(searchTravelInsurance);
            }
            int adults = 0; int child = 0;
            if (!string.IsNullOrEmpty(searchTravelInsurance.ageSelf) && Convert.ToInt32(searchTravelInsurance.ageSelf) > 17)
            {
                adults = 1;
            }
            if (!string.IsNullOrEmpty(searchTravelInsurance.ageSpouse))
            {
                adults += 1;
            }
            if (!string.IsNullOrEmpty(searchTravelInsurance.ageChild1))
            {
                child += 1;
            }
            if (!string.IsNullOrEmpty(searchTravelInsurance.ageChild2))
            {
                child += 1;
            }
            if (!string.IsNullOrEmpty(searchTravelInsurance.ageFather))
            {
                adults += 1;
            }
            if (!string.IsNullOrEmpty(searchTravelInsurance.ageMother))
            {
                adults += 1;
            }
            if (!string.IsNullOrEmpty(searchTravelInsurance.ageBrother) && Convert.ToInt32(searchTravelInsurance.ageSelf) > 17)
            {
                adults += 1;
            }
            else
            {
                child += 1;
            }
            var Tid = _ITravelBusiness.SaveTravelSearch(searchTravelInsurance);
            return RedirectToAction("QResult/" + Tid, "TravelInsurance", new { @ageSelf = searchTravelInsurance.ageSelf, @destination = searchTravelInsurance.destination, @stayDays = searchTravelInsurance.stayDays, @adults = adults.ToString(), @children = child.ToString(), @travellerName = searchTravelInsurance.travellerName, @tripStartDate = searchTravelInsurance.tripStartDate, @tripEndDate = searchTravelInsurance.tripEndDate, @City = searchTravelInsurance.City, @phone = searchTravelInsurance.Phone, @Email = searchTravelInsurance.Email,@AgeSpouse=searchTravelInsurance.ageSpouse,@agechild1=searchTravelInsurance.ageChild1,@agechild2=searchTravelInsurance.ageChild2,@ageFather=searchTravelInsurance.ageFather,@ageMother=searchTravelInsurance.ageMother});

        }
        public ActionResult QResult(string Id, string ageSelf, string destination, string stayDays, string travellerName, string tripStartDate, string tripEndDate, string City, string Phone, string Email, string AgeSpouse, string agechild1, string agechild2, string ageFather, string ageMother)
        {
            BindDropdown();
            BindCoverageAmount();
            ViewData["ageSelf"] = ageSelf ?? "0";
            ViewData["ageSpouse"] = AgeSpouse ?? "0";
            ViewData["ageChild1"] = agechild1 ?? "0";
            ViewData["ageChild2"] = agechild2 ?? "0";
            ViewData["ageFather"] = ageFather ?? "0";
            ViewData["ageMother"] = ageMother ?? "0";
            ViewData["destination"] = destination;
            ViewData["stayDays"] = stayDays;
            ViewData["TId"] = Id;
            ViewData["travellerName"] = travellerName;
            ViewData["tripStartDate"] = tripStartDate;
            ViewData["tripEndDate"] = tripEndDate;
            ViewData["city"] = City;
            ViewData["phone"] = Phone;
            ViewData["email"] = Email;
            // Login Session Code........
            //Session["id2"] = ViewData["TId"].ToString();
            //Session["agesel2"] = ViewData["ageSelf"].ToString();
            //Session["destination2"] = ViewData["destination"].ToString();
            //Session["stayDays2"] = ViewData["stayDays"].ToString();
            //Session["travellerName2"] = ViewData["travellerName"].ToString();
            //Session["tripStartDate2"] = ViewData["tripStartDate"].ToString();
            //Session["tripEndDate2"] = ViewData["tripEndDate"].ToString();
            //Session["city2"] = ViewData["city"].ToString();
            //Session["phone2"] = ViewData["phone"].ToString();
            //Session["email2"] = ViewData["email"].ToString();
            return View();
        }
        [HttpPost]
        public JsonResult BindPremiumList(int draw, int start, int length, string searchTxt, string ageSelf, string destination, string stayDays, string txtTriptype, string Suminsured, string travellerName, string tripStartDate, string tripEndDate, string City, string Phone, string Email,string agespouse,string agechild1, string agechild2,string agefather,string agemother)
            
        {
            JsonTableData jsonData = new JsonTableData();

            try
            {
                string searchKey = Request["search[value]"];
                string order = Request["order[0][column]"];
                string orderby = Request["order[0][dir]"];
                searchTxt = searchKey.Trim().ToLower();
                SearchTravelInsurance objSearchTravelInsurance = new SearchTravelInsurance();
                objSearchTravelInsurance.ageSelf = ageSelf;
                objSearchTravelInsurance.ageSpouse = agespouse;
                objSearchTravelInsurance.ageChild1 = agechild1;
                objSearchTravelInsurance.ageChild2 = agechild2;
                objSearchTravelInsurance.ageFather = agefather;
                objSearchTravelInsurance.ageMother = agemother;
                objSearchTravelInsurance.stayDays = stayDays;
                objSearchTravelInsurance.destination = destination;
                objSearchTravelInsurance.tripType = txtTriptype;
                objSearchTravelInsurance.SumInsured = Suminsured;
                View_TravelInsuranceModel objser1 = new View_TravelInsuranceModel();
                objser1.ageSelf = ageSelf;
                objser1.ageSpouse = agespouse;
                objser1.ageChild1 = agechild1;
                objser1.ageChild2 = agechild2;
                objser1.ageFather = agefather;
                objser1.ageMother = agemother;
                objser1.stayDays = stayDays;
                objser1.destination = destination;
                objser1.tripType = txtTriptype;
                objser1.travellerName = travellerName;
                DateTime Startdob = DateTime.ParseExact(tripStartDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                objser1.tripStartDate = Startdob.ToString("yyyy-MM-dd");
                DateTime Enddob = DateTime.ParseExact(tripEndDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                objser1.tripEndDate = Enddob.ToString("yyyy-MM-dd");
                objser1.City = City;
                objser1.Phone = Phone;
                objser1.Email = Email;
                objser1.SumInsured = Convert.ToDecimal(Suminsured);
                List<View_TravelInsuranceModel> l = _ITravelBusiness.GetPakageList(objser1);
                objser1.pakegecode = objser1.pakegecode;
                var clist = l;
                foreach (var item in clist)
                {
                    objser1.pakegecode = item.pakegecode;
                }
                objSearchTravelInsurance.Loading = "Loading...........";
                View_TravelInsuranceModel bhartObj = new View_TravelInsuranceModel();
                bhartObj.ageSelf = ageSelf;
                bhartObj.ageSpouse = agespouse;
                bhartObj.ageChild1 = agechild1;
                bhartObj.ageChild2 = agechild2;
                bhartObj.ageFather = agefather;
                bhartObj.ageMother = agemother;
                bhartObj.stayDays = stayDays;
                bhartObj.destination = destination;
                bhartObj.tripType = txtTriptype;
                bhartObj.travellerName = travellerName;
              //  DateTime Startdob = DateTime.ParseExact(tripStartDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                bhartObj.tripStartDate = Startdob.ToString("yyyy-MM-dd");
               // DateTime Enddob = DateTime.ParseExact(tripEndDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                bhartObj.tripEndDate = Enddob.ToString("yyyy-MM-dd");
                bhartObj.City = City;
                bhartObj.Phone = Phone;
                bhartObj.Email = Email;
                bhartObj.SumInsured = Convert.ToDecimal(Suminsured); 
               
                List<View_TravelInsuranceModel> list = _ITravelBusiness.GetPremiumList(objSearchTravelInsurance);
                List<View_TravelInsuranceModel> lstedlewise = _ITravelBusiness.GetPremiumGodigitResponce(objser1);
              List<View_TravelInsuranceModel> lstquato = _ITravelBusiness.SubmitQuato(bhartObj);
                int bookingid = Convert.ToInt32(objser1.SearchId);
                ViewData["BookingId"] = bookingid.ToString();
                lstedlewise.AddRange(lstquato);
                list.AddRange(lstedlewise);
                var commonList = list;
                commonList = list;
                
                    if (!string.IsNullOrEmpty(searchTxt))
                    {
                        //commonList = commonList.Where(x => x.EDesigName.ToLower().Trim().Contains(searchTxt.ToLower().Trim())).ToList();
                    }

                    switch (order)
                    {

                        //case "1":
                        //    commonList = orderby.Equals("asc") ? commonList.OrderBy(x => x.EDesigName).ToList() : commonList.OrderByDescending(x => x.EDesigName).ToList();
                        //    break;


                        default:
                            commonList = orderby.Equals("desc") ? commonList.OrderBy(x => x.SumInsured).ToList() : commonList.OrderByDescending(x => x.SumInsured).ToList();
                            break;
                    }


                    jsonData.recordsTotal = commonList.Count;
                    jsonData.recordsFiltered = commonList.Count;
                    jsonData.draw = draw;
                    commonList = length != -1 ? commonList.Skip(start).Take(length).ToList() : commonList;
                    List<List<string>> DetailList = new List<List<string>>();
                    string action = string.Empty;


                    var i = 1;
                    foreach (var item in commonList)
                    {
                        int day = Convert.ToInt32(objSearchTravelInsurance.stayDays);
                        if (day >= 91 && item.LogoImage == "/Logo/bhartiaxa-logo.png")
                        { }
                        else
                        {
                            string column1 = "<img src=" + item.LogoImage + " />";
                            string column2 = "<p>" + item.Plans.ToUpper() + "<p>";
                            string column3 = "<p>" + item.SumInsured + "<p>";
                            string column4Premium = "<span><i class='fa fa-inr' aria-hidden='true'></i></span> " + item.Premium + "<br src='#'><a class='AddD' href='#' onclick='NavigateDetail(" + item.Travel_id + ","+item.CompanyId+")'>Buy This Plan</a>";
                            //string col4 = "<button  style='border:none;' onclick='navigateEdit(" + item.EDesigId + ")'  type='submit'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></button><button onclick='navigatedel(" + item.EDesigId + ")' style='border:none;' type='submit'><i class='fa fa-trash-o' aria-hidden='true'></i></button>";
                            List<string> common = new List<string>();
                            common.Add(column1);
                            common.Add(column2);
                            common.Add(column3);
                            common.Add(column4Premium);

                            DetailList.Add(common);
                        }


                    }
                
                    jsonData.data = DetailList;
                    objSearchTravelInsurance.Loading = "";
                    return new JsonResult()
                    {
                        Data = jsonData,
                        MaxJsonLength = Int32.MaxValue,
                        JsonRequestBehavior = JsonRequestBehavior.AllowGet
                    };
                }
            
            catch (Exception)
            {
                // (new CreateLogFile()).ErrorLog(ex.ToString());
                return Json(null);
            }
        }

        public ActionResult GetDetail(string Id, string tid, string compid)
        {
            compid = "10005";
            ////Login Session Code 
            //if (Session["UserName"] == null)
            //{
            //    Session["IdNum2"] = Id;

            //}

            //if (Session["UserName"] != null)
            //{


            //    SearchTravelInsurance searchTravelInsurance = new SearchTravelInsurance();
            //    if (Id == null)
            //    {
            //        string Tid = Session["id2"].ToString();
            //        tid = Tid;
            //        Id = Session["IdNum22"].ToString();
            //        Response.Cookies["page"].Value = "";
            //    }
            //}
            //else
            //{
            //    Response.Cookies["page"].Value = "GetDetail";
            //    Response.Cookies["page"].Expires = DateTime.Now.AddHours(1);
            //    return RedirectToAction("LoginDetails", "RegistrationLogin");
            //}

            //// End..............
            
            GetQuotationDetail quotationDetail = new GetQuotationDetail(); ;
            try
            {
                BindPurpose();
                BindDesease();
                BindVisaType();
                BindRelationStar();
                BindRelations();
                BindPlaceOfVisit(compid);
                BindAssigneeRelation("travel", Convert.ToInt32(Id));
                if (string.IsNullOrEmpty(Id) || string.IsNullOrEmpty(tid))
                {
                    return RedirectToAction("GetQuote");
                }

                SelectList lstPassport = new SelectList(isPassport);
                ViewData["lstPassport"] = lstPassport;
                quotationDetail = _ITravelBusiness.GetQuotationDetail(Id, tid, compid);

            }
            catch (Exception ex)
            {

                (new ErrorLog()).Error("getdetail-controller=", ex.Message.ToString());
            }

            return View(quotationDetail);

        }

        [HttpPost]
        //public ActionResult GetDetail(string Id, string tid,GetQuotationDetail quotationDetail )
        public ActionResult GetDetail()
        {
            
            var form = Request.Form;
            var formData = form.AllKeys.Where(p => form[p] != "null").ToDictionary(p => p, p => form[p]);

            if (Request.Form["travelDeclaration"] != null)
            { 
            formData["travelDeclaration"] = "true" ;
            }
            
            var formDataSerialize = JsonConvert.SerializeObject(formData);
            var quotationDetail = JsonConvert.DeserializeObject<GetQuotationDetail>(formDataSerialize);
            SelectList lstPassport = new SelectList(isPassport);
            ViewData["lstPassport"] = lstPassport;

            if (!ModelState.IsValid || quotationDetail.travelDeclaration==false)
            {
                BindPurpose();
                BindDesease();
                BindVisaType();
                BindRelations();
                BindRelationStar();
                BindPlaceOfVisit(quotationDetail.CompanyID.ToString());
                BindAssigneeRelation("travel", Convert.ToInt32(quotationDetail.PlanId));
                return View(quotationDetail);
            }
            _IProposerBusiness.SaveInfo(quotationDetail);
            _ITravellerBusiness.SaveInfo(quotationDetail);
            int companyid = quotationDetail.CompanyID;
            switch (companyid)
            {
                case 10005:
                    var res = _ITravelBusiness.SubmitProposal(quotationDetail);
                    if (!string.IsNullOrEmpty(res) && !res.Contains("error"))
                    {
                        ViewBag.SecretKey = secretKey;
                        ViewBag.APIKey = apiKey;
                        ViewBag.referenceId = res;
                    }
                    else
                    {
                        ViewData["Error"] = res.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");
                    }
                    break;
                case 10004:
                    var res1 = _IBhartiAxaTravel.SubmitProposal(quotationDetail);

                    if (res1 != null && res1.OrderNo != null)
                    {
                        ViewBag.OrderNo = res1.OrderNo;
                        ViewBag.QuatoNo = res1.QuoteNo;
                        ViewBag.Channel = res1.Channel;
                        ViewBag.Product = res1.Product;
                        //ViewBag.Amount = res1.Amount;
                        ViewBag.Amount = res1.Amount;
                        ViewBag.referenceId = "0";
                        // return RedirectToAction("ProposalStatus", "TravelInsurance", new { @refid = res });
                    }
                    else
                    {
                        // ViewData["Error"] = res1.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");
                    }
                    break;
                //case 10008:
                //    var res1 = _IBhartiAxaTravel.SubmitProposal(quotationDetail);

                //    if (res1 != null && res1.OrderNo != null)
                //    {
                //        ViewBag.OrderNo = res1.OrderNo;
                //        ViewBag.QuatoNo = res1.QuoteNo;
                //        ViewBag.Channel = res1.Channel;
                //        ViewBag.Product = res1.Product;
                //        ViewBag.Amount = res1.Amount;
                //        ViewBag.referenceId = "0";
                //        // return RedirectToAction("ProposalStatus", "TravelInsurance", new { @refid = res });
                //    }
                //    else
                //    {
                //        // ViewData["Error"] = res1.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");
                //    }
                //    break;
                default:
                    break;
            }

            BindPurpose();
            BindDesease();
            BindVisaType();
            BindRelations();
            BindRelationStar();
            BindPlaceOfVisit(quotationDetail.CompanyID.ToString());
            BindAssigneeRelation("travel", Convert.ToInt32(quotationDetail.PlanId));


            return View(quotationDetail);

        }


        public ActionResult GetDetailGodigit(string Id, string tid, string SumInsuried)
        {
            GetQuotationDetail quotationDetail = new GetQuotationDetail(); ;
            try
            {
                BindGender();
                BindState();
                BindIProfession();
                BindVisaType();
                BindRelations();
                BindRelationStar();
                BindPlaceOfVisit(quotationDetail.CompanyID.ToString());
                BindPurpose();
                BindCountry();
                BindMarialStatus();
                BindRelationGodit();
               
              //  bookingid = ViewData["BookingId"].ToString();
                //BindAssigneeRelation("travel", Convert.ToInt32(Id));
                if (string.IsNullOrEmpty(Id) || string.IsNullOrEmpty(tid))
                {
                    return RedirectToAction("GetQuote");
                }
                
                SelectList lstPassport = new SelectList(isPassport);
                ViewData["lstPassport"] = lstPassport;
                quotationDetail = _ITravelBusiness.GetQuotationDetailGodigit(Id, tid,SumInsuried);

            }
            catch (Exception ex)
            {

                (new ErrorLog()).Error("getdetail-controller=", ex.Message.ToString());
            }

            return View(quotationDetail);
        }

        [HttpPost]
        public ActionResult GetDetailGodigit()
        {
            var form = Request.Form;
            var formData = form.AllKeys.Where(p => form[p] != "null").ToDictionary(p => p, p => form[p]);

            if (Request.Form["travelDeclaration"] != null)
            {
                formData["travelDeclaration"] = "true";
            }
            
            var formDataSerialize = JsonConvert.SerializeObject(formData);
            var quotationDetail = JsonConvert.DeserializeObject<GetQuotationDetail>(formDataSerialize);
            SelectList lstPassport = new SelectList(isPassport);
            ViewData["lstPassport"] = lstPassport;
            _IProposerBusiness.SaveInfo(quotationDetail);
            _ITravellerBusiness.SaveInfo(quotationDetail);
            int companyid = quotationDetail.CompanyID;
            BindGender();
            BindState();
            BindIProfession();
            BindVisaType();
            BindRelations();
            BindRelationStar();
            BindPlaceOfVisit(quotationDetail.CompanyID.ToString());
            BindPurpose();
            BindCountry();
            BindMarialStatus();
            BindRelationGodit();
            var res = _ITravelBusiness.SubmitProposalGodigit(quotationDetail);
            return View(quotationDetail);
        }

        public ActionResult GetCity(string pinCode)
        {

            var response = _ITravelBusiness.GetCityList(pinCode);
            var result = response != null && !response[0].Contains("error") ? new { data = response, status = "success" } : new { data = response, status = "error" };
            return Json(result, JsonRequestBehavior.AllowGet);

        }
        public ActionResult GetArea(string pinCode, string cityId)
        {

            var response = _ITravelBusiness.GetArea(pinCode, cityId);
            return Json(response, JsonRequestBehavior.AllowGet);

        }
        public ActionResult ProposalStatus(string refid)
        {
            ViewBag.SecretKey = secretKey;
            ViewBag.APIKey = apiKey;
            ViewBag.referenceId = refid;
            return View();
        }
        [HttpPost]
        public ActionResult GenerateToken(string refId)
        {
            var redirectToken = _ITravelBusiness.GenerateToken(refId);
            // var redirectToken = "60b393827113566ce99e5160373c5331";
            ViewBag.RedirectToken = redirectToken;
            return Json(new { token = redirectToken }, JsonRequestBehavior.AllowGet);
        }

      

        //[HttpPost]
        //public ActionResult getPayment(string refId)
        //{
        //    var redirectToken = _ITravelBusiness.GenerateToken(refId);
        //    // var redirectToken = "60b393827113566ce99e5160373c5331";
        //    ViewBag.RedirectToken = redirectToken;
        //    return Json(new { token = redirectToken }, JsonRequestBehavior.AllowGet);
        //}
        public ActionResult GetPaymentStatus(string purchaseToken)
        {
            if (!string.IsNullOrEmpty(purchaseToken))
            {
                var policyStatus = _ITravelBusiness.PolicyStatus(purchaseToken);
                if (policyStatus.Count == 4)
                {
                    ViewBag.ReferenceNumber = (policyStatus["RefNumber"] ?? "").ToString();
                    ViewBag.PolicyNumber = policyStatus["PolicyNumber"].ToString();
                    ViewBag.RefId = policyStatus["RefId"].ToString();
                    ViewBag.PolicyStatus = policyStatus["PolicyStatus"].ToString();
                }
                else
                {
                    ViewBag.RefId = policyStatus["RefId"].ToString();
                    ViewBag.PolicyStatus = policyStatus["PolicyStatus"].ToString();
                    ViewBag.Note = policyStatus["Note"].ToString().Replace("{", "").Replace("}", "").Replace(@"""", "");

                }


            }
            
            return View();
        }
        [HttpGet]
        public ActionResult Download(string refid)
        {

            var response = _ITravelBusiness.GetDocument(refid);
            return File(response, "application/pdf");

        }

        public ActionResult GetPaymentStatusBhartiAxa(string productID, string orderNo, string amount, string status, string transactionRef, string policyNo, string link, string emailId)
        {
            GetPaymentStatusBhartiAxa payment = new GetPaymentStatusBhartiAxa();
            payment.productID = productID;
            payment.orderNo = orderNo;
            payment.amount = amount;
            payment.status = status;
            payment.transactionRef = transactionRef;
            payment.policyNo = policyNo;
            payment.link = link;
            payment.emailId = emailId;
            var policyStatus = _ITravelBusiness.PolicyBhartiaxaStatus(payment);
            ViewBag.PolicyStatus = status;
            ViewData["Status"] = status;
            if (ViewBag.PolicyStatus == "success")
            {
                var link1 = link.Split('/').Last();
                ViewData["transactionRef"] = transactionRef;
                ViewData["policyNo"] = policyNo;
                ViewBag.PolicyNumber =ViewData["policyNo"].ToString();
                ViewBag.RefId =ViewData["transactionRef"].ToString();
                ViewData["link"] = link1;
                ViewData["Note"]= "";
            }
            else 
            {
                ViewData["transactionRef"] = transactionRef;
                ViewData["policyNo"] = policyNo;
                ViewBag.RefId = ViewData["transactionRef"].ToString();
                ViewBag.PolicyStatus = status;
                ViewData["Note"] = "Payment Fail";
                return RedirectToAction("Fail","TravelInsurance");
              
            }
            

           return View();
        }

        public ActionResult Fail()
        {
            return View();
        }
        public ActionResult GetGodigitPaymentStatus(string transactionNumber)
        {
            //pppppppppppppppppppppppppppppppppp
            if (!string.IsNullOrEmpty(transactionNumber))
            {
                GodigitDetails obj = new GodigitDetails();
                var policyId = _ITravelBusiness.PolicyPay(transactionNumber);
                ViewData["policyNumber"] = policyId;
                obj.policyID = policyId;
                var res = _ITravelBusiness.GetPolicyPDf(obj);
                ViewBag.Shedulepath = obj.schedulePath;
                ViewBag.success = obj.message;
            }
            //pppppppppppppppppppppppppppppppppp
            return View();
        }

        //...........................For Bharti Axa
        public ActionResult GetDetailBhartiAxa(string Id, string tid,string compid)
        {
            compid = "10004";
            ////Login Session Code 
            //if (Session["UserName"] == null)
            //{
            //    Session["IdNum2"] = Id;

            //}

            //if (Session["UserName"] != null)
            //{


            //    SearchTravelInsurance searchTravelInsurance = new SearchTravelInsurance();
            //    if (Id == null)
            //    {
            //        string Tid = Session["id2"].ToString();
            //        tid = Tid;
            //        Id = Session["IdNum22"].ToString();
            //        Response.Cookies["page"].Value = "";
            //    }
            //}
            //else
            //{
            //    Response.Cookies["page"].Value = "GetDetail";
            //    Response.Cookies["page"].Expires = DateTime.Now.AddHours(1);
            //    return RedirectToAction("LoginDetails", "RegistrationLogin");
            //}

            //// End..............

            GetQuotationDetail quotationDetail = new GetQuotationDetail(); ;
            try
            {
                BindPurpose();
                BindDesease();
                BindVisaType();
                BindRelationStar();
                BindRelations();
                BindPlaceOfVisit(compid);
                BindAssigneeRelation("travel", Convert.ToInt32(Id));
                if (string.IsNullOrEmpty(Id) || string.IsNullOrEmpty(tid))
                {
                    return RedirectToAction("GetQuote");
                }

                SelectList lstPassport = new SelectList(isPassport);
                ViewData["lstPassport"] = lstPassport;
                quotationDetail = _ITravelBusiness.GetQuotationDetail(Id, tid, compid);

            }
            catch (Exception ex)
            {

                (new ErrorLog()).Error("getdetail-controller=", ex.Message.ToString());
            }

            return View(quotationDetail);

        }

        [HttpPost]
        //public ActionResult GetDetail(string Id, string tid,GetQuotationDetail quotationDetail )
        public ActionResult GetDetailBhartiAxa()
        {

            var form = Request.Form;
            var formData = form.AllKeys.Where(p => form[p] != "null").ToDictionary(p => p, p => form[p]);

            if (Request.Form["travelDeclaration"] != null)
            {
                formData["travelDeclaration"] = "true";
            }

            var formDataSerialize = JsonConvert.SerializeObject(formData);
            var quotationDetail = JsonConvert.DeserializeObject<GetQuotationDetail>(formDataSerialize);
            SelectList lstPassport = new SelectList(isPassport);
            ViewData["lstPassport"] = lstPassport;

            if (!ModelState.IsValid || quotationDetail.travelDeclaration == false)
            {
                BindPurpose();
                BindDesease();
                BindVisaType();
                BindRelations();
                BindRelationStar();
                BindPlaceOfVisit(quotationDetail.CompanyID.ToString());
                BindAssigneeRelation("travel", Convert.ToInt32(quotationDetail.PlanId));
                return View(quotationDetail);
            }
            _IProposerBusiness.SaveInfo(quotationDetail);
            _ITravellerBusiness.SaveInfo(quotationDetail);
            int companyid = quotationDetail.CompanyID;
            switch (companyid)
            {
                case 10005:
                    var res = _ITravelBusiness.SubmitProposal(quotationDetail);
                    if (!string.IsNullOrEmpty(res) && !res.Contains("error"))
                    {
                        ViewBag.SecretKey = secretKey;
                        ViewBag.APIKey = apiKey;
                        ViewBag.referenceId = res;
                    }
                    else
                    {
                        ViewData["Error"] = res.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");
                    }
                    break;
                case 10004:
                    var res1 = _IBhartiAxaTravel.SubmitProposal(quotationDetail);

                    if (res1 != null && res1.OrderNo != null)
                    {
                        ViewBag.OrderNo = res1.OrderNo;
                        ViewBag.QuatoNo = res1.QuoteNo;
                        ViewBag.Channel = res1.Channel;
                        ViewBag.Product = res1.Product;
                        //ViewBag.Amount = res1.Amount;
                        ViewBag.Amount = res1.Amount;
                        ViewBag.referenceId = "0";
                        // return RedirectToAction("ProposalStatus", "TravelInsurance", new { @refid = res });
                    }
                    else
                    {
                        // ViewData["Error"] = res1.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");
                    }
                    break;
                //case 10008:
                //    var res1 = _IBhartiAxaTravel.SubmitProposal(quotationDetail);

                //    if (res1 != null && res1.OrderNo != null)
                //    {
                //        ViewBag.OrderNo = res1.OrderNo;
                //        ViewBag.QuatoNo = res1.QuoteNo;
                //        ViewBag.Channel = res1.Channel;
                //        ViewBag.Product = res1.Product;
                //        ViewBag.Amount = res1.Amount;
                //        ViewBag.referenceId = "0";
                //        // return RedirectToAction("ProposalStatus", "TravelInsurance", new { @refid = res });
                //    }
                //    else
                //    {
                //        // ViewData["Error"] = res1.Replace("\"", "").Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "");
                //    }
                //    break;
                default:
                    break;
            }

            BindPurpose();
            BindDesease();
            BindVisaType();
            BindRelations();
            BindRelationStar();
            BindPlaceOfVisit(quotationDetail.CompanyID.ToString());
            BindAssigneeRelation("travel", Convert.ToInt32(quotationDetail.PlanId));


            return View(quotationDetail);

        }
        //.......................................
    }
}